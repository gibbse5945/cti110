r = int(input())
g = int(input())
b = int(input())
smallest_num = 0

if (r < g) and (r < b):
    smallest_num = r
elif (g < r) and (g < b):     #this conditional finds the smallest variable
    smallest_num = g          #out of the 3 inputs
else:
    smallest_num = b
    
no_grey_r = r - smallest_num  #New variables without the 'grey' value,
no_grey_g = g - smallest_num  #which is the 'equal part' i.e.
no_grey_b = b - smallest_num  #the smallest number in eac color

print(f'{no_grey_r} {no_grey_g} {no_grey_b}')