service1 = 'Oil change'
service2 = 'Tire rotation'
service3 = 'Car wash'

name1 = 'oil change'
name2 = 'tire rotation'
name3 = 'car wash'

price1 = 35
price2 = 19
price3 = 7

auto_service = input('Enter desired auto service:\n')

if auto_service in service1:
    print('You entered: {}'.format(service1))
    print('Cost of {}: ${}'.format(name1, price1))

elif auto_service in service2:
    print('You entered: {}'.format(service2))
    print('Cost of {}: ${}'.format(name2, price2))
    
elif auto_service in service3:
    print('You entered: {}'.format(service3))
    print('Cost of {}: ${}'.format(name3, price3))
    
else:
    print('You entered: {}'.format(auto_service))
    print('Error: Requested service is not recognized')